# Design System: Kingdom Future (Saudi Vision 2030)

## 1. Concept & Philosophy
**"Heritage Meets Horizon"**

The **Kingdom Future** design system is crafted to embody the spirit of Saudi Vision 2030. It merges the deep, authoritative roots of tradition with the boundless optimism of a high-tech future. It is not just a "dark mode"; it is a digital representation of a modern, prosperous Kingdom.

*   **Keywords:** Authority, Prosperity, Innovation, Heritage, Visionary.
*   **Atmosphere:** A desert night sky illuminated by the green glow of cybernetic infrastructure.

## 2. Color Palette

### Primary: Neon Emerald
*   **Hex:** `#00E676` (Approximate for `hsl(150 100% 45%)`)
*   **Usage:** Primary actions, active states, key data visualization.
*   **Meaning:** Represents growth, prosperity, and the national identity, electrified for the digital age.

### Secondary: Royal Gold
*   **Hex:** `#F2C94C` (Approximate for `hsl(45 90% 50%)`)
*   **Usage:** "Royal Tier" badges, premium features, financial data.
*   **Meaning:** Wealth, prestige, and the golden sands of the desert.

### Background: The Deep Void
*   **Hex:** `#040B06` (Approximate for `hsl(150 30% 3%)`)
*   **Usage:** Application background.
*   **Meaning:** The vast depth of the night sky, providing a high-contrast canvas for the neon accents.

### Surface: Glassmorphism
*   **Effect:** `backdrop-blur-md` with `bg-white/5`
*   **Usage:** Cards, sidebars, headers.
*   **Meaning:** Transparency and clarity in governance.

## 3. Typography

### Display: 'Outfit'
*   **Style:** Geometric, bold, modern sans-serif.
*   **Usage:** Headers (H1-H3), Hero text.
*   **Character:** Approachable yet distinctively futuristic.

### Body: 'Inter'
*   **Style:** Clean, legible, neutral sans-serif.
*   **Usage:** UI text, data tables, paragraphs.
*   **Character:** Functional and invisible, letting the content shine.

## 4. Visual Elements

*   **Iconography:** `Lucide React` icons with neon glow effects (`drop-shadow`).
*   **Charts:** Gradient fills using the Emerald and Gold palette.
*   **Imagery:** Abstract geometric patterns evoking digital data streams merging with traditional architectural motifs.

## 5. Usage Guidelines

*   **Do:** Use the Gold accent sparingly. It should feel special, not overwhelming.
*   **Do:** Maintain high contrast. The text must always be legible against the deep background.
*   **Don't:** Use standard blue or red without tinting them to match the environment (e.g., use Teal instead of Blue).
