# Design System: Neural Dark

## 1. Concept & Philosophy
**"The Pulse of Intelligence"**

The **Neural Dark** design system is inspired by the aesthetics of cyberpunk, artificial intelligence, and deep neural networks. It is designed for data-heavy, high-performance environments where the user needs to feel connected to a living, thinking system.

*   **Keywords:** Intelligence, Connectivity, Speed, Cybernetic, Deep.
*   **Atmosphere:** Inside the machine—a boundless void traversed by pulses of light and data.

## 2. Color Palette

### Primary: Neon Purple
*   **Hex:** `#7C3AED` (Approximate for `hsl(263 70% 50%)`)
*   **Usage:** Primary navigation, focus rings, brand identity.
*   **Meaning:** Wisdom, creativity, and the mystery of the "black box" of AI.

### Secondary: Electric Cyan
*   **Hex:** `#22D3EE` (Approximate for `hsl(190 100% 50%)`)
*   **Usage:** Data streams, connectivity indicators, secondary actions.
*   **Meaning:** Energy, flow, and electricity.

### Background: The Neural Void
*   **Hex:** `#09090B` (Approximate for `hsl(240 10% 3.9%)`)
*   **Usage:** Main canvas.
*   **Meaning:** A neutral, deep space that reduces eye strain during long monitoring sessions.

## 3. Typography

### Display: 'Outfit'
*   **Style:** Geometric sans-serif.
*   **Usage:** Large numbers, dashboard headers.
*   **Vibe:** Technical and precise.

### Body: 'Inter' or 'JetBrains Mono' (Optional for code)
*   **Style:** Standard sans-serif.
*   **Usage:** General interface text.

## 4. Visual Elements

*   **Glow Effects:** Heavy use of `box-shadow` and `text-shadow` to simulate light emission.
*   **Borders:** Subtle, translucent white borders (`border-white/10`) to define edges in the dark.
*   **Gradients:** Radial gradients in the background to suggest depth and light sources.

## 5. Usage Guidelines

*   **Do:** Use glow effects to indicate active or "live" elements.
*   **Do:** Use the Cyan color for real-time updates and "heartbeat" animations.
*   **Don't:** Use flat colors. Everything should have a sense of depth or luminance.
